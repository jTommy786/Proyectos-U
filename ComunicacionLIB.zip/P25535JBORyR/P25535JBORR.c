/*
Jose Julian Bonilla Morales.
#5535.
Relaciones de recurrencia.
*/
#include <stdio.h>
#include <string.h>
#include "C:\Users\julia\Documents\Programacion\funciones.h.txt" //Libreria personal(local), de las funciones recursivas.

/*
Programa principal.
*/
int main(){
    int opcion, num, i; //Variables numericas a ingresar.
    char cadena[100]; //Declaracion de la variable como una dimension.
    //Inicializacion inicial de variables para mantener seguridad de ejecucion.
    opcion=0;
    num=0;

    //Se desea ejecutar al menos una vez.
    do{
        //Mostrar la disposicion del menu y sus opciones, asi como su lectura
        printf("\n------------");
        printf("\n   Menu.");
        printf("\n------------"); //Las lineas sirven para diferenciar la ejecucion de una iteracion de otra.
        printf("\n\n1.Invertir cadena.");
        printf("\n2. Calculo de factorial.");
        printf("\n3. Sucesion de Fibonacci hasta n numeros.");
        printf("\n4. Salir.");
        printf("\n-Seleccione una opcion: ");
        scanf("%i", &opcion);
        //Switch case sera la mejor opcion para elegir de una variedad de opciones(en forma numerica).
          

        switch(opcion){
            case 1://Invertir cadena.
                printf("\nIngrese una palabra: ");
                while (getchar() != '\n'); // Limpia el búfer
                fgets(cadena, sizeof(cadena), stdin);
                printf("\nLa cadena ingresada es: %s", cadena);
                InvertirCadena(cadena, 0, strlen(cadena) - 1);
                printf("\nLa cadena al reves es: %s", cadena);
            break;
            case 2://Calculo de factorial.
                do{
                printf("Ingrese un numero positivo: "); //El usuario debe digitar un numero positivo entero.
                scanf("%i", &num); //Escaneo del numero    
                //Verificacion de que el numero ingresado sea positivo.
                if(num<0){
                    printf("-*Ingrese un numero permitido.*-");
                }
                }while(num<0);
                printf("\nEl factorial del numero %i es %i", num, factorial(num));
                //Se llama a la funcion factorial desde la libreria para que regrese la ejecucion completa.
            break;
            case 3: //Calculo de Fibonacci.
                do{
                printf("Ingrese un numero positivo hasta donde calcular Fibonacci: "); //El usuario debe digitar un numero positivo entero.
                scanf("%i", &num); //Escaneo del numero    
                //Verificacion de que el numero ingresado sea positivo.
                if(num<0){
                    printf("-*Ingrese un numero permitido.*-");
                }
                }while(num<0);
                /*
                Se usa el bucle for para ejecutar correctamente la funcion fibonacci hasta el numero deseado,
                el bucle debe ir desde 0 hasta que el contador 'i' sea menor al numero ingresado.
                */
               for(i=0; i<num; i++){
                printf("%i ", fibonacci(i));
               }
               printf("\n");
            break;
            case 4: //El programa se terminara si presiona la opcion 4.
                printf("\nFin de linea."); 
            break;
            default: //En caso de poner cualquier otro valor fuera de rango, esta es la salida predeterminada, por lo que el programa se repetira.
                printf("\nIngrese una opcion valida.");
            break;
        }

    }while(opcion!=4);//En caso de digitar una opcion fuera de rango se debe reiniciar el programa y volver a ingresar la opcion.


    return 0; //Finalizar el programa.
}
